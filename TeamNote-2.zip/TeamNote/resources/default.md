# 欢迎使用该软件
``` int main(){int a;}```
