#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <DMainWindow>
#include <DMenu>
#include <DMenuBar>
#include <DToolBar>
#include <DLabel>
#include <DScrollArea>
#include "widget.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE
DWIDGET_USE_NAMESPACE

class MainWindow : public DMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void initMenu();
    void initToolBar();
    void intiConnect();

private:
    Widget *w;
    Ui::MainWindow *ui;

    DLabel *imageLable;
    DScrollArea *scrollaera;

    DMenu *fileMenu;
    DMenu *viemMenu;
    DMenu *helpMenu;

    QToolBar *fileToolBar;

    QAction *openAct;

};

#endif // MAINWINDOW_H
